const GOOGLE_SCRIPT_ID = 'google-identity-services'
const SESSION_KEY = 'lifeos_google_session'
const GOOGLE_SCRIPT_TIMEOUT = 8000
const TOKEN_SKEW_MS = 60_000

const GOOGLE_SCOPES = [
  'https://www.googleapis.com/auth/drive.file',
  'openid',
  'email',
  'profile',
].join(' ')

let tokenClient = null
let accessToken = null
let tokenExpiresAt = 0

function getClientId() {
  const clientId = import.meta.env.VITE_GOOGLE_CLIENT_ID?.trim()
  if (!clientId) {
    throw new Error('Missing VITE_GOOGLE_CLIENT_ID in .env')
  }
  return clientId
}

function loadGoogleScript() {
  return new Promise((resolve, reject) => {
    if (window.google?.accounts?.oauth2) {
      resolve(window.google)
      return
    }

    const existing = document.getElementById(GOOGLE_SCRIPT_ID)
    if (existing) {
      existing.addEventListener('load', () => resolve(window.google))
      existing.addEventListener('error', reject)
      return
    }

    const script = document.createElement('script')
    script.id = GOOGLE_SCRIPT_ID
    script.src = 'https://accounts.google.com/gsi/client'
    script.async = true
    script.defer = true
    script.onload = () => resolve(window.google)
    script.onerror = reject
    document.body.appendChild(script)

    window.setTimeout(() => {
      if (!window.google?.accounts?.oauth2) {
        reject(new Error('Google auth script timed out'))
      }
    }, GOOGLE_SCRIPT_TIMEOUT)
  })
}

async function fetchGoogleUserProfile(token) {
  const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
    headers: { Authorization: `Bearer ${token}` },
  })

  if (!res.ok) throw new Error('Failed to fetch Google profile')

  const data = await res.json()

  return {
    id: data.sub || '',
    name: data.name || 'Google User',
    email: data.email || '',
    picture: data.picture || '',
  }
}

function isTokenExpired(expiresAt) {
  const value = Number(expiresAt || 0)
  return value > 0 && Date.now() >= value - TOKEN_SKEW_MS
}

function persistSession(token, user, expiresInSeconds = 3600) {
  accessToken = token
  tokenExpiresAt = Date.now() + Math.max(0, Number(expiresInSeconds)) * 1000

  localStorage.setItem(
    SESSION_KEY,
    JSON.stringify({
      accessToken: token,
      tokenExpiresAt,
      user,
    })
  )
}

function clearSession() {
  accessToken = null
  tokenExpiresAt = 0
  localStorage.removeItem(SESSION_KEY)
}

export function getStoredSession() {
  try {
    const raw = localStorage.getItem(SESSION_KEY)
    if (!raw) return null

    const session = JSON.parse(raw)

    if (isTokenExpired(session.tokenExpiresAt)) {
      clearSession()
      return null
    }

    if (session?.accessToken) {
      accessToken = session.accessToken
      tokenExpiresAt = Number(session.tokenExpiresAt || 0)
    }

    return session
  } catch {
    return null
  }
}

export function getAccessToken() {
  const token = accessToken || getStoredSession()?.accessToken || null
  if (!token) return null

  if (isTokenExpired(tokenExpiresAt)) {
    return null
  }

  return token
}

export async function initializeGoogleAuth() {
  await loadGoogleScript()

  if (!tokenClient) {
    tokenClient = window.google.accounts.oauth2.initTokenClient({
      client_id: getClientId(),
      scope: GOOGLE_SCOPES,
      callback: () => {},
    })
  }

  return true
}

export async function refreshAccessToken() {
  const currentToken = getAccessToken()
  if (currentToken) return currentToken

  const session = await signInWithGoogle()
  return session?.accessToken || getAccessToken()
}

export async function signInWithGoogle() {
  await initializeGoogleAuth()

  return new Promise((resolve, reject) => {
    tokenClient.callback = async (response) => {
      if (response?.error) {
        reject(new Error(response.error))
        return
      }

      try {
        const token = response.access_token
        const expiresIn = Number(response.expires_in || 3600)
        const user = await fetchGoogleUserProfile(token)
        persistSession(token, user, expiresIn)
        resolve({ accessToken: token, user })
      } catch (error) {
        reject(error)
      }
    }

    tokenClient.requestAccessToken({ prompt: 'consent' })
  })
}

export function signOutGoogle() {
  const token = getAccessToken()

  clearSession()

  try {
    if (token && window.google?.accounts?.oauth2?.revoke) {
      window.google.accounts.oauth2.revoke(token, () => {})
    }
  } catch {
    // ignore revoke errors
  }
}
